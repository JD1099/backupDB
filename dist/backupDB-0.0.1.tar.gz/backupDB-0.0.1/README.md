# backupDB

This is an incomplete project.

The name of this project is not accurate. Half way through writing the script I changed my mind a few times.

So far this script simply creates a config file intended to store values for the mysql python connector.
I want the config file to be secure enough to safely store a password. A major component of this script is checking and making sure only the owner of the config can read the contents.

Generally I would say I don't know what I am doing. Ultimatly I want my script to be secure, but I still need to learn how to do that.
